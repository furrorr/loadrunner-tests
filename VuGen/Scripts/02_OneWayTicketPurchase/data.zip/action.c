Action()
{

	lr_start_transaction("02_OneWayTicketPurchase");

	lr_start_transaction("HomePage");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("MSO=SID&1648565942; DOMAIN=127.0.0.1");

	web_add_cookie("MTUserInfo=firstName&sergey&username&sergey&address2&Ekaterinburg&hash&89&address1&lenina%20123&lastName&ageev%0A; DOMAIN=127.0.0.1");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("welcome.pl", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/WebTours/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("HomePage",LR_AUTO);

	lr_start_transaction("Login");

	web_add_header("Origin", 
		"http://127.0.0.1:1080");

	web_add_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(8);

	web_submit_data("login.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=body", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=133548.350263264zizQDQDpczzzzzzHtVcVzpDfQz", ENDITEM, 
		"Name=username", "Value=sergey", ENDITEM, 
		"Name=password", "Value=pass", ENDITEM, 
		"Name=login.x", "Value=34", ENDITEM, 
		"Name=login.y", "Value=7", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	web_add_cookie("yandexuid=4879413561632641113; DOMAIN=mail.yandex.ru");

	web_add_cookie("yuidss=4879413561632641113; DOMAIN=mail.yandex.ru");

	web_add_cookie("ymex=1948001183.yrts.1632641183#1948001183.yrtsi.1632641183; DOMAIN=mail.yandex.ru");

	web_add_cookie("is_gdpr=0; DOMAIN=mail.yandex.ru");

	web_add_cookie("gdpr=0; DOMAIN=mail.yandex.ru");

	web_add_cookie("_ym_uid=1632642798647894685; DOMAIN=mail.yandex.ru");

	web_add_cookie("is_gdpr_b=CMm0CBDaRygC; DOMAIN=mail.yandex.ru");

	web_add_cookie("L=e15kd0VKWloGR3NCUlcLe1RmAlQKfG1OJSMVCAUrfAUmGn9ZcQ==.1632651956.14740.327684.f8a5d21b1b9d2a6b8171964bcaf27d8f; DOMAIN=mail.yandex.ru");

	web_add_cookie("yandex_login=ageeff.ser220; DOMAIN=mail.yandex.ru");

	web_add_cookie("i=Ku0C5QfMa56RMxB/A3H3zsTTL+Tw7n55+dp9m0Qj79/r5IjWF/oF6wRuF1O9zo0K41oww4poQaGEeRAFghbV9X2nzY8=; DOMAIN=mail.yandex.ru");

	web_add_cookie("my=YwA=; DOMAIN=mail.yandex.ru");

	web_add_cookie("yp=1948011956.udn.cDrQodC10YDQs9C10Lk%3D#1649564641.szm.1_25:1536x864:1536x722#1641752816.ygu.1#1639420016.clh.2327486; DOMAIN=mail.yandex.ru");

	web_add_cookie("_ym_d=1640945026; DOMAIN=mail.yandex.ru");

	web_add_cookie("skid=7795696381641037791; DOMAIN=mail.yandex.ru");

	web_add_cookie("yabs-frequency=/5/0000000000000000/iY-PFDtI_ssRHFp____QagJCGnBgSfX48000/; DOMAIN=mail.yandex.ru");

	web_add_cookie("instruction=1; DOMAIN=mail.yandex.ru");

	web_add_cookie("ys=udn.cDrQodC10YDQs9C10Lk%3D#c_chck.1275550386; DOMAIN=mail.yandex.ru");

	web_add_cookie("stngs=stngs.1%3Anewspaper%3A0%3Atrue%3Atrue; DOMAIN=mail.yandex.ru");

	web_add_cookie("_skin=lite; DOMAIN=mail.yandex.ru");

	web_add_cookie("y360w.xpnd.201121439=0; DOMAIN=mail.yandex.ru");

	web_add_cookie("ymai_iale=1; DOMAIN=mail.yandex.ru");

	web_add_cookie("Session_id=3:1648349659.5.0.1632651956568:IAb4sg:1a.1.2:1|201121439.0.2|3:250027.334964.3l8zUmge3D2bsHmTCSloqJUQJFg; DOMAIN=mail.yandex.ru");

	web_add_cookie("sessionid2=3:1648349659.5.0.1632651956568:IAb4sg:1a.1.2:1|201121439.0.2|3:250027.334964.3l8zUmge3D2bsHmTCSloqJUQJFg; DOMAIN=mail.yandex.ru");

	web_add_cookie("_yasc=ErAjLpig8OVi0OQrTUlzzxmuYzdLZg8QLVwrj5l9+bKRz4skwK0UQNeTHbRb2h2Z; DOMAIN=mail.yandex.ru");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Origin", 
		"https://mail.yandex.ru");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_custom_request("service-worker-config", 
		"URL=https://mail.yandex.ru/u2709/api/service-worker-config", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/service-worker?clid=2256450&from=dist_bookmark&uid=201121439&win=225", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"_uid\":\"201121439\",\"_locale\":\"ru\",\"_connection_id\":\"LIZA-64070387-1648353332561\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_custom_request("liza1", 
		"URL=https://mail.yandex.ru/web-api/models/liza1?_m=app-badge-counter", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/service-worker?clid=2256450&from=dist_bookmark&uid=201121439&win=225", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"_locale\":\"ru\",\"_connection_id\":\"LIZA-64070387-1648353332561\",\"_exp\":\"404892,0,-1;406173,0,-1;457741,0,-1;455818,0,55;539433,0,50;451868,0,77;550189,0,43;428729,0,75;500413,0,8;380961,0,82;512791,0,17;500420,0,23;538275,0,17;261663,0,34;118737,0,26;512772,0,45;456408,0,88;453083,0,16;317929,0,22;92934,0,22;471696,0,13;381544,0,17\",\"_eexp\":\"404892,0,-1;406173,0,-1;457741,0,-1;455818,0,55;539433,0,50;451868,0,77;550189,0,43;428729,0,75;500413,0,8;380961,0,82;500420,0,23;261663,0"
		",34;118737,0,26;512772,0,45;456408,0,88;453083,0,16;317929,0,22;381544,0,17\",\"models\":[{\"name\":\"app-badge-counter\",\"params\":{}}],\"_ckey\":\"ukWbItAGrTzatnp9L+SuAg2pJa4=!l1f5pebe\"}", 
		LAST);

	web_add_auto_header("Origin", 
		"https://mail.yandex.ru");

	web_custom_request("liza1_2", 
		"URL=https://mail.yandex.ru/web-api/models/liza1?_m=messages", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/service-worker?clid=2256450&from=dist_bookmark&uid=201121439&win=225", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"_uid\":\"201121439\",\"_locale\":\"ru\",\"_connection_id\":\"LIZA-64070387-1648353332561\",\"_exp\":\"404892,0,-1;406173,0,-1;457741,0,-1;455818,0,55;539433,0,50;451868,0,77;550189,0,43;428729,0,75;500413,0,8;380961,0,82;512791,0,17;500420,0,23;538275,0,17;261663,0,34;118737,0,26;512772,0,45;456408,0,88;453083,0,16;317929,0,22;92934,0,22;471696,0,13;381544,0,17\",\"_eexp\":\"404892,0,-1;406173,0,-1;457741,0,-1;455818,0,55;539433,0,50;451868,0,77;550189,0,43;428729,0,75;500413,0,8;380961,0,"
		"82;500420,0,23;261663,0,34;118737,0,26;512772,0,45;456408,0,88;453083,0,16;317929,0,22;381544,0,17\",\"models\":[{\"name\":\"messages\",\"params\":{\"filter_ids\":\"179018085187987871\"}}],\"_timestamp\":1648654405495,\"_messages_per_page\":1,\"_ckey\":\"ukWbItAGrTzatnp9L+SuAg2pJa4=!l1f5pebe\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_custom_request("liza1_3", 
		"URL=https://mail.yandex.ru/web-api/models/liza1?_m=do-service-worker-log", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/service-worker?clid=2256450&from=dist_bookmark&uid=201121439&win=225", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"_uid\":\"201121439\",\"_locale\":\"ru\",\"_connection_id\":\"LIZA-64070387-1648353332561\",\"_exp\":\"404892,0,-1;406173,0,-1;457741,0,-1;455818,0,55;539433,0,50;451868,0,77;550189,0,43;428729,0,75;500413,0,8;380961,0,82;512791,0,17;500420,0,23;538275,0,17;261663,0,34;118737,0,26;512772,0,45;456408,0,88;453083,0,16;317929,0,22;92934,0,22;471696,0,13;381544,0,17\",\"_eexp\":\"404892,0,-1;406173,0,-1;457741,0,-1;455818,0,55;539433,0,50;451868,0,77;550189,0,43;428729,0,75;500413,0,8;380961,0,"
		"82;500420,0,23;261663,0,34;118737,0,26;512772,0,45;456408,0,88;453083,0,16;317929,0,22;381544,0,17\",\"models\":[{\"name\":\"do-service-worker-log\",\"params\":{\"params\":\"{\\\"count\\\":1,\\\"pool\\\":\\\"messages-201121439\\\",\\\"type\\\":\\\"info\\\",\\\"timestamp\\\":1648654405743,\\\"mid\\\":\\\"179018085187987871\\\",\\\"reason\\\":\\\"notification-show\\\",\\\"source\\\":\\\"u2709-push\\\"}\"}}],\"_ckey\":\"ukWbItAGrTzatnp9L+SuAg2pJa4=!l1f5pebe\"}", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("Flights");

	web_revert_auto_header("DNT");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	lr_think_time(20);

	web_url("plugins_win.json", 
		"URL=https://www.gstatic.com/chrome/config/plugins_3/plugins_win.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("welcome.pl_2", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Flights",LR_AUTO);

	web_add_auto_header("Origin", 
		"http://127.0.0.1:1080");

	lr_think_time(11);

	web_submit_data("reservations.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=03/31/2022", ENDITEM, 
		"Name=arrive", "Value=Frankfurt", ENDITEM, 
		"Name=returnDate", "Value=04/01/2022", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=61", ENDITEM, 
		"Name=findFlights.y", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	web_submit_data("reservations.pl_2", 
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=010;386;03/31/2022", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=reserveFlights.x", "Value=55", ENDITEM, 
		"Name=reserveFlights.y", "Value=15", ENDITEM, 
		LAST);

	return 0;
}